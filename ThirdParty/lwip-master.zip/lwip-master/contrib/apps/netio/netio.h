#ifndef LWIP_NETIO_H
#define LWIP_NETIO_H

void netio_init(void);

#endif /* LWIP_NETIO_H */
